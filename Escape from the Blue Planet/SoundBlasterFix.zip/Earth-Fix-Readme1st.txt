SB-Live! Fix for Earth2150
==========================


In der original Vollversion von Earth2150
scheint ein BUG enthalten zu sein. Diese
l��t SB-Live Besitzer fast verzweifeln da
dass Spiel permanent nach kurzer Zeit abst�rzt,
wenn es denn es �berhaupt startet.

Ich �bernehme kein Garantie, dass der Fix bei
euch funktioniert, bei mir tut er dass.


Vorgehensweise:
===============

1. Earth2150 deinstallieren, falls zuvor installiert 
2. Earth2150 neu installieren
3. Setup.exe im Earth2150 Hauptverzeichniss starten und 
   die Grafikeinstellung w�hlen
4. Earth2150 starten und bis ins Haupmenu laden lassen. 
   (Nun hat Earth2150 eure Soundkarte erkannt u. in der
    Registry eingetragen, allerdings falsch)
5. Das Spiel beenden und zur�ck zu Windows
6. Nun einfach meinen FIX "Earth2150-Fix.reg" doppelklicken
   und die nachfolgende Frage mit Ja beantworten, dann nochmals
   kurz auf OK klicken, dass wars.
7. Earth2150 wie gewohnt starten, der Fix braucht nur 1x ausgef�hrt
   zu werden.



gru�


Deathbringer


PS: Bitte besucht doch mal meine Homepage unter WWW.ONLINERACING.DE



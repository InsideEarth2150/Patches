Earth 2150
----------

earthnet fix

company: Topware Interactive (www.topware.de) /
	 Strategic Simulations Inc. (www.ssionline.com)

- enables access to Earthnet multiplayer servers for owners
  of the SSI/Mattel release of Earth 2150

Just double-click in explorer windows on earthnet.reg to
install this fix.
